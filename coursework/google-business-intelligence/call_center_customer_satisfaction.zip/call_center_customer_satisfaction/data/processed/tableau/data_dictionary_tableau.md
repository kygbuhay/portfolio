# 📘 Auto-Generated Data Dictionary

## kpi_daily.csv
| Column | Pandas Dtype | Non-Null % | Example Value |
|---|---|---:|---|
| `date_created` | object | 100.0% | 2022-01-12 |
| `market` | object | 100.0% | market_3 |
| `problem_type` | object | 100.0% | type_4 |
| `first_calls` | int64 | 100.0% | 0 |
| `repeat_calls` | int64 | 100.0% | 1 |
| `total_calls` | int64 | 100.0% | 1 |
| `repeat_call_rate` | float64 | 100.0% | 1.0 |
| `first_contact_resolution` | float64 | 100.0% | 0.0 |

## kpi_market_summary.csv
| Column | Pandas Dtype | Non-Null % | Example Value |
|---|---|---:|---|
| `market` | object | 100.0% | market_1 |
| `first_calls` | int64 | 100.0% | 45333 |
| `repeat_calls` | int64 | 100.0% | 12647 |
| `total_calls` | int64 | 100.0% | 57980 |
| `rcr_pct` | float64 | 100.0% | 21.81 |
| `fcr_pct` | float64 | 100.0% | 78.19 |

## kpi_monthly.csv
| Column | Pandas Dtype | Non-Null % | Example Value |
|---|---|---:|---|
| `month_start` | object | 100.0% | 2022-01-01 |
| `market` | object | 100.0% | market_1 |
| `problem_type` | object | 100.0% | type_1 |
| `first_calls` | int64 | 100.0% | 1018 |
| `repeat_calls` | int64 | 100.0% | 326 |
| `total_calls` | int64 | 100.0% | 1344 |
| `repeat_call_rate` | float64 | 100.0% | 0.2425595238095238 |
| `first_contact_resolution` | float64 | 100.0% | 0.757440476190476 |

## kpi_weekly.csv
| Column | Pandas Dtype | Non-Null % | Example Value |
|---|---|---:|---|
| `week_start` | object | 100.0% | 2022-01-16 |
| `market` | object | 100.0% | market_2 |
| `problem_type` | object | 100.0% | type_1 |
| `first_calls` | int64 | 100.0% | 25 |
| `repeat_calls` | int64 | 100.0% | 0 |
| `total_calls` | int64 | 100.0% | 25 |
| `repeat_call_rate` | float64 | 100.0% | 0.0 |
| `first_contact_resolution` | float64 | 100.0% | 1.0 |

## repeat_calls_long.csv
| Column | Pandas Dtype | Non-Null % | Example Value |
|---|---|---:|---|
| `date_created` | object | 100.0% | 2022-03-23 |
| `market` | object | 100.0% | market_3 |
| `problem_type` | object | 100.0% | type_2 |
| `days_after_first` | int64 | 100.0% | 7 |
| `call_count` | int64 | 100.0% | 2 |
