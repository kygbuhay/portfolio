# 📋 QUICK REFERENCE CARD

**Print this or keep it visible while working!**

---

## 🎯 Project Goal
Build a Tableau dashboard analyzing repeat call rates for Google Fiber call centers

---

## 📊 Core Metrics (Memorize These!)

| Metric | Formula | Good Target |
|--------|---------|-------------|
| **RCR** (Repeat Call Rate) | repeat_calls ÷ total_calls | <15% |
| **FCR** (First Contact Resolution) | 1 - RCR | >85% |

---

## 📁 File Structure

```
google-fiber-repeat-calls/
├── README.md                    ← Update with findings
├── 3_DAY_SPEEDRUN.md           ← Your execution plan
├── DAY_1_SPEEDRUN.md           ← Start here!
├── data/
│   ├── raw/                     ← Put Coursera CSVs here
│   └── processed/               ← Export BigQuery results here
├── sql/
│   ├── 01_union_all.sql        ← Run this first
│   ├── 02_kpi_calculations.sql ← Run this second
│   └── 03_long_form_rollups.sql ← Optional/advanced
├── docs/
│   ├── data_dictionary.md       ← Document your data
│   └── insights_summary.md      ← Write findings here
└── assets/screenshots/          ← Dashboard screenshots
```

---

## ⚡ Execution Order

### Day 1 (2h): Setup
1. Download 3 CSVs from Coursera
2. Upload to BigQuery → dataset: `fiber`
3. Run 01_union_all.sql (replace `your_project`)
4. Run 02_kpi_calculations.sql
5. Export 3 CSVs for Tableau
6. Git commit

### Day 2 (4h): Dashboard
1. Connect Tableau to kpi_daily.csv
2. Build KPI cards (RCR, FCR, Total Calls)
3. Market comparison chart
4. Problem type chart
5. Trend line over time
6. Simple table (rubric requirement)
7. Save + test interactivity

### Day 3 (4h): Insights
1. Analyze dashboard (1 hour - really explore!)
2. Write 5 findings in insights_summary.md
3. Write 3 recommendations
4. Update README with key insights
5. Publish to Tableau Public
6. Git commit + push

---

## 🔧 SQL Commands You'll Use

```sql
-- Check data loaded
SELECT COUNT(*) FROM `your_project.fiber.market_1`;

-- View KPI summary
SELECT * FROM `your_project.fiber.kpi_market_summary`;

-- Export for Tableau
SELECT * FROM `your_project.fiber.kpi_daily`
ORDER BY date_created;
```

**Remember:** Replace `your_project` with your actual GCP project ID!

---

## 🎨 Tableau Dashboard Layout

```
┌─────────────────────────────────────────────────┐
│  Google Fiber Repeat Call Analysis             │
├─────────┬─────────┬─────────┬─────────────────┤
│  RCR %  │  FCR %  │  Calls  │   Date Range    │  ← KPI Cards
├─────────────────────────────────────────────────┤
│                                                 │
│  [Bar Chart: RCR by Market]                    │  ← Market comparison
│                                                 │
├─────────────────────┬───────────────────────────┤
│                     │                           │
│  [Bar: RCR by      │  [Line: RCR over time]    │  ← Problem types + trend
│   Problem Type]     │                           │
│                     │                           │
├─────────────────────┴───────────────────────────┤
│  [Table: Market × Type × RCR]                  │  ← Simple table
└─────────────────────────────────────────────────┘
```

---

## 🆘 Common Issues

| Problem | Solution |
|---------|----------|
| "Table not found" | Check BigQuery dataset name = `fiber` |
| "Cannot parse date" | Verify date_created is DATE type |
| RCR > 100% | Check your SUM formulas in SQL |
| Tableau won't connect | Export CSVs, don't use live BigQuery |
| Git push fails | Run `git pull` first, resolve conflicts |

---

## ✅ Quality Checks

**Before moving to next day:**
- [ ] Can I query all tables in BigQuery?
- [ ] Do KPI numbers seem reasonable? (RCR 5-40%)
- [ ] Did I commit changes to Git?

**Before calling it done:**
- [ ] Dashboard has 6+ visualizations?
- [ ] README has quantified insights?
- [ ] Tableau is published + link works?
- [ ] Can I explain this in 2 minutes?

---

## 🎓 Portfolio Talking Points

**For interviews:**
> "I analyzed 500K+ call center interactions across three markets using BigQuery and Tableau. I identified that Market 3 had a 28% repeat call rate—nearly double the industry benchmark. By drilling into the data, I found that specific issue categories were driving 40% of repeats. I recommended process improvements that could reduce repeat rates by 5-10%, translating to operational cost savings."

**Key skills demonstrated:**
- SQL (unions, aggregations, window functions)
- Data visualization (Tableau)
- Business metrics (RCR, FCR)
- Stakeholder communication
- Reproducible analytics pipeline

---

## 💡 Quick Wins

**If you're ahead of schedule:**
- Add month-over-month trend indicators
- Include day-offset analysis (03_long_form_rollups.sql)
- Create executive summary slide
- Record 3-min video walkthrough

**If you're behind schedule:**
- Skip 03_long_form_rollups.sql (it's optional)
- Use simple bar/line charts only (no fancy stuff)
- Keep insights to 3 instead of 5
- Just get it DONE ✅

---

## 🧠 Mindset Mantras

1. "Done is better than perfect"
2. "This is simpler than Project #3"
3. "Baseline first, enhancements later"
4. "3 days max, then submit"
5. "I've already proven I can do this"

---

**Keep this visible. Reference it often. You got this! 💪**
