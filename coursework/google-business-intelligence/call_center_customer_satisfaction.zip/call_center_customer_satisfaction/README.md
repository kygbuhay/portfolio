# Google Fiber Repeat Calls Analysis

> **Business Intelligence Capstone** | Operational dashboard analyzing customer support efficiency across three markets

## 🎯 Executive Summary

[**2-3 sentence business problem**]
Google Fiber's call center experiences repeat customer calls, indicating potential gaps in first-contact resolution. This analysis identifies patterns in repeat-call behavior across markets and issue types to drive operational improvements.

[**Key findings - fill after Day 3**]
1. Market [X] shows 2x higher repeat rates than others due to [issue type]
2. [Problem type] accounts for 40% of repeat calls, suggesting [action]
3. [Temporal pattern] indicates [opportunity]

## 📊 Dashboard

**Live Tableau Dashboard:** [Link after publish]

**Key Metrics:**
- **Repeat Call Rate (RCR):** [X]% | Target: <15%
- **First Contact Resolution (FCR):** [X]% | Target: >85%
- **Total Calls Analyzed:** [X]k over 12 months

## 🔍 Methodology

**Data Sources:** 3 market CSVs (market_1, market_2, market_3) containing daily call volumes with 7-day repeat tracking

**Analysis Approach:**
1. Unioned multi-market data in BigQuery
2. Calculated RCR/FCR by market, problem type, and time period
3. Visualized trends in Tableau with drill-down capabilities

**Tools:** SQL (BigQuery), Tableau, Git

## 💡 Business Recommendations

[**Fill after analysis - 3-5 actionable recommendations**]

1. **[Action for highest-impact insight]**
   - What: [specific change]
   - Why: [data-driven reasoning]
   - Expected impact: [quantified if possible]

2. **[Second priority]**
   - ...

## 📁 Repository Structure

```
google-fiber-repeat-calls/
├── data/
│   ├── raw/              # Original CSVs
│   └── processed/        # Cleaned/unioned data
├── sql/
│   ├── 01_union_all.sql
│   ├── 02_kpi_calculations.sql
│   └── 03_long_form_rollups.sql
├── docs/
│   ├── data_dictionary.md
│   └── insights_summary.md
└── assets/
    └── screenshots/
```

## 🛠️ Technical Highlights

- **Data Transformation:** Wide-to-long pivot for flexible aggregation
- **KPI Engineering:** Calculated RCR, FCR, and repeat volume metrics
- **Performance:** Pre-aggregated all metrics in SQL for fast dashboard rendering
- **Accessibility:** Compliant design with alt text, high contrast, and screen-reader support

## 📝 Project Context

Final capstone project for Google Business Intelligence Certificate. Portfolio demonstrates:
- Multi-source data integration
- Operational KPI design for call center analytics
- Stakeholder-ready data visualization
- Reproducible SQL pipeline

---

**Contact:** [Your info]  
**Certificate:** Google Business Intelligence Professional Certificate  
**Date:** October 2025
