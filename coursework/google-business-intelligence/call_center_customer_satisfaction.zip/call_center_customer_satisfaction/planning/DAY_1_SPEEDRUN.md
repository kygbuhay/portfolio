# DAY 1 SPEEDRUN CHECKLIST ⚡
**Goal:** Data loaded, SQL working, dashboard structure ready  
**Time:** 2 hours max

---

## ☐ STEP 1: Get the Data (15 min)

1. **Download from Coursera:**
   - Go to: Coursera → Google BI Certificate → Capstone Project
   - Download 3 CSVs: `market_1.csv`, `market_2.csv`, `market_3.csv`
   - Save to: `/data/raw/` folder

2. **Quick scan (Excel/Sheets):**
   - Open market_1.csv
   - Count rows: _______
   - Note column names (should have contacts_n, contacts_n_1... contacts_n_7, date_created, new_type)
   - Spot-check: do the numbers make sense?

---

## ☐ STEP 2: Upload to BigQuery (20 min)

### Create Dataset
```
1. Go to BigQuery console
2. Click your project → "Create Dataset"
3. Name: fiber
4. Location: US (multi-region)
5. Click "Create Dataset"
```

### Upload 3 CSVs
```
For EACH of the 3 files:
1. Click fiber dataset → "Create Table"
2. Source: "Upload" → Choose file (market_1.csv, market_2.csv, market_3.csv)
3. Table name: market_1, market_2, market_3 (MUST match SQL file names)
4. Auto-detect schema: ✓ CHECKED
5. Click "Create Table"
6. Wait for green checkmark (30 seconds each)
```

### Validate Upload
```sql
-- Copy-paste each query, verify you get results:

SELECT COUNT(*) as rows, MIN(date_created) as first, MAX(date_created) as last 
FROM `your_project.fiber.market_1`;

SELECT COUNT(*) FROM `your_project.fiber.market_2`;

SELECT COUNT(*) FROM `your_project.fiber.market_3`;
```

**✓ If all 3 queries return numbers, you're good!**

---

## ☐ STEP 3: Run SQL Files (30 min)

### File 1: Union All Markets
1. Open `sql/01_union_all.sql` in text editor
2. **FIND & REPLACE:** `your_project` → [your actual GCP project ID]
   - (It's in the BigQuery URL after `/project/`)
3. Copy entire file → Paste into BigQuery editor
4. Click "Run" (takes ~10 seconds)
5. **Run validation queries at bottom of file**
6. You should see a new VIEW: `repeat_calls_all_markets`

### File 2: KPI Calculations
1. Open `sql/02_kpi_calculations.sql`
2. **FIND & REPLACE:** `your_project` → [your GCP project ID]
3. Copy → Paste → Run (takes ~30 seconds)
4. **Run validation queries at bottom**
5. You should see 4 new TABLES:
   - `kpi_daily`
   - `kpi_weekly`
   - `kpi_monthly`
   - `kpi_market_summary`

### Validate KPIs
```sql
-- Does this return 3 rows with reasonable percentages?
SELECT market, rcr_pct, fcr_pct, total_calls
FROM `your_project.fiber.kpi_market_summary`
ORDER BY rcr_pct DESC;
```

**✓ If you see 3 markets with RCR between 5-40%, you're golden!**

---

## ☐ STEP 4: Export for Tableau (15 min)

### Export Daily Data
```sql
SELECT *
FROM `your_project.fiber.kpi_daily`
ORDER BY date_created, market, problem_type;
```
- Click "Save Results" → Download as CSV
- Save to: `/data/processed/kpi_daily.csv`

### Export Weekly Data
```sql
SELECT *
FROM `your_project.fiber.kpi_weekly`
ORDER BY week_start, market, problem_type;
```
- Download as CSV → `/data/processed/kpi_weekly.csv`

### Export Market Summary
```sql
SELECT *
FROM `your_project.fiber.kpi_market_summary`;
```
- Download as CSV → `/data/processed/kpi_market_summary.csv`

**✓ You now have 3 CSVs ready for Tableau!**

---

## ☐ STEP 5: Quick Data Documentation (20 min)

### Update Data Dictionary
1. Open `docs/data_dictionary.md`
2. Fill in "Data Quality Notes" section:
   - Date range: [your dates]
   - Total rows: [your count]
   - Problem types: [list the new_type values you see]

### Update Problem Type Mapping
Run this to see what types exist:
```sql
SELECT 
  new_type as problem_type,
  COUNT(*) as frequency,
  ROUND(AVG(repeat_call_rate) * 100, 1) as avg_rcr_pct
FROM `your_project.fiber.kpi_daily`
GROUP BY problem_type
ORDER BY frequency DESC;
```

Now fill in the "Problem Type Mapping" table in data_dictionary.md with actual types.

---

## ☐ STEP 6: Create GitHub Repo (15 min)

```bash
cd /path/to/your/project/folder
git init
git add .
git commit -m "Initial commit: data loaded, SQL working"

# Create repo on GitHub (go to github.com/new)
# Then connect:
git remote add origin https://github.com/YOUR_USERNAME/google-fiber-repeat-calls.git
git push -u origin main
```

---

## ☐ STEP 7: Basic Tableau Connection (10 min)

**SKIP building the dashboard today - just test the connection:**

1. Open Tableau Desktop/Public
2. Connect to Data → Text file
3. Select `/data/processed/kpi_daily.csv`
4. Check Data Source tab - do you see columns?
5. Drag `date_created` to Columns, `total_calls` to Rows
6. See a line chart? **✓ Connection works!**
7. Save as `google_fiber_dashboard.twb` (don't build yet)

---

## 🎉 END OF DAY 1

### What You Accomplished:
- ✅ Data uploaded to BigQuery
- ✅ SQL union + KPI calculations working
- ✅ 3 clean CSVs exported for Tableau
- ✅ Data documented
- ✅ GitHub repo created
- ✅ Tableau connection tested

### What's Next (Day 2):
- Build Tableau dashboard (3-4 hours)
- Create KPI cards, trend charts, and comparison visuals
- Add filters and formatting

### 🆘 Stuck? Come back to Claude with:
1. Which step you're on
2. The exact error message (screenshot helps)
3. What you tried

---

**Time Check:** If you hit 2 hours, STOP. Come back to Claude and we'll troubleshoot. Don't burn out on Day 1! 🧠
