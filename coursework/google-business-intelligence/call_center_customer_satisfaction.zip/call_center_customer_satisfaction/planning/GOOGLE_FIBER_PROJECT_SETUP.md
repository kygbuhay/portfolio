# Google Fiber Call Center Dashboard - Project Setup

## 📋 Project Overview

**Goal:** Build a live dashboard analyzing call center metrics for Google Fiber to improve customer satisfaction

**Deliverables:**
- Interactive Tableau dashboard
- Data model documentation
- SQL queries for data transformation
- Presentation-ready insights

**Timeline:** 2-3 weeks (capstone project)

---

## 🎯 What Makes This Different from Project #3

| AI ROI Project | Google Fiber Project |
|----------------|---------------------|
| Stack Overflow survey data | Call center operational data |
| Analyzing trends over time | Real-time metrics & KPIs |
| Developer productivity focus | Customer satisfaction focus |
| Historical analysis | Operational dashboard |

---

## 📁 Recommended File Structure

```
google-fiber-dashboard/
├── README.md
├── data/
│   ├── raw/              # Original datasets
│   └── processed/        # Cleaned CSVs for Tableau
├── sql/
│   ├── 01_data_prep.sql
│   ├── 02_kpi_calculations.sql
│   └── 03_dashboard_views.sql
├── tableau/
│   └── google_fiber_dashboard.twb
├── docs/
│   ├── data_dictionary.md
│   ├── kpi_definitions.md
│   └── project_requirements.md
└── presentation/
    └── executive_summary.pdf
```

---

## ✅ Phase 0: Setup & Understanding (Day 1)

### Tasks:
- [ ] Download Google Fiber dataset from Coursera
- [ ] Review project requirements document
- [ ] Identify key stakeholders (call center managers, executives)
- [ ] Define success metrics (what makes a "good" call center?)
- [ ] Create GitHub repo: `google-fiber-call-center-dashboard`
- [ ] Set up local folder structure

### Key Questions to Answer:
1. What are the most important call center KPIs?
   - Average handle time (AHT)
   - First call resolution (FCR)
   - Customer satisfaction score (CSAT)
   - Call volume trends
   - Repeat callers

2. Who uses this dashboard?
   - Call center managers (operational decisions)
   - Executives (strategic overview)
   - Team leads (performance monitoring)

3. What time periods matter?
   - Daily (operational)
   - Weekly (trending)
   - Monthly (reporting)

---

## ✅ Phase 1: Data Understanding (Days 2-3)

### Tasks:
- [ ] Load data into BigQuery or local database
- [ ] Explore dataset structure
- [ ] Document all columns in data dictionary
- [ ] Check data quality (nulls, outliers, duplicates)
- [ ] Identify granularity (one row = one call? one day?)
- [ ] Map fields to business questions

### SQL Exploration Queries:
```sql
-- Row count and date range
SELECT 
  COUNT(*) as total_rows,
  MIN(call_date) as first_date,
  MAX(call_date) as last_date
FROM calls;

-- Call volume by day
SELECT 
  call_date,
  COUNT(*) as calls
FROM calls
GROUP BY call_date
ORDER BY call_date;

-- Top call reasons
SELECT 
  call_reason,
  COUNT(*) as frequency
FROM calls
GROUP BY call_reason
ORDER BY frequency DESC
LIMIT 10;
```

---

## ✅ Phase 2: KPI Definition & Calculation (Days 4-5)

### Core KPIs to Calculate:

**1. Average Handle Time (AHT)**
```sql
SELECT 
  DATE_TRUNC(call_date, WEEK) as week,
  AVG(call_duration_minutes) as avg_handle_time
FROM calls
GROUP BY week;
```

**2. First Call Resolution Rate**
```sql
SELECT 
  DATE_TRUNC(call_date, WEEK) as week,
  COUNTIF(resolved_on_first_call = TRUE) / COUNT(*) as fcr_rate
FROM calls
GROUP BY week;
```

**3. Repeat Caller Analysis**
```sql
WITH caller_counts AS (
  SELECT 
    customer_id,
    COUNT(*) as call_count
  FROM calls
  WHERE call_date BETWEEN '2024-01-01' AND '2024-12-31'
  GROUP BY customer_id
)
SELECT 
  CASE 
    WHEN call_count = 1 THEN 'One-time'
    WHEN call_count <= 3 THEN 'Low frequency'
    WHEN call_count <= 10 THEN 'Medium frequency'
    ELSE 'High frequency'
  END as caller_type,
  COUNT(*) as customers
FROM caller_counts
GROUP BY caller_type;
```

**4. Customer Satisfaction Score (CSAT)**
```sql
SELECT 
  call_reason,
  AVG(satisfaction_score) as avg_csat,
  COUNT(*) as sample_size
FROM calls
WHERE satisfaction_score IS NOT NULL
GROUP BY call_reason
HAVING COUNT(*) >= 30  -- Minimum sample size
ORDER BY avg_csat;
```

### Tasks:
- [ ] Calculate all KPIs in SQL
- [ ] Validate calculations (do they make sense?)
- [ ] Export results to CSV for Tableau
- [ ] Document KPI definitions

---

## ✅ Phase 3: Dashboard Design (Days 6-8)

### Dashboard Structure:

**Page 1: Executive Overview**
- KPI scorecard (4-6 big numbers)
- Trend lines (calls over time, CSAT over time)
- Key insights callout boxes

**Page 2: Operational Metrics**
- Call volume by hour/day
- AHT by team/agent
- First call resolution trends
- Call reason breakdown

**Page 3: Customer Analysis**
- Repeat caller patterns
- CSAT by call reason
- Geographic distribution (if available)
- Customer journey analysis

### Tasks:
- [ ] Sketch dashboard wireframes on paper
- [ ] Identify which charts need which data
- [ ] Create Tableau data source from CSV exports
- [ ] Build KPI scorecards
- [ ] Add trend visualizations
- [ ] Add filters (date range, call reason, team)
- [ ] Test interactivity

---

## ✅ Phase 4: Insights & Recommendations (Days 9-10)

### Key Questions to Answer:
1. **What's driving high call volumes?**
   - Top call reasons
   - Peak times/days
   - Seasonal patterns

2. **Where are satisfaction issues?**
   - Low CSAT call reasons
   - Long handle times
   - Repeat callers not getting resolved

3. **What's working well?**
   - High FCR rates
   - Efficient call reasons
   - High satisfaction areas

### Tasks:
- [ ] Analyze dashboard for patterns
- [ ] Document 5-7 key findings
- [ ] Create actionable recommendations
- [ ] Prepare executive summary (1 page)

---

## ✅ Phase 5: Documentation & Presentation (Days 11-14)

### Deliverables:
- [ ] Polished Tableau dashboard
- [ ] GitHub README with project overview
- [ ] Data dictionary
- [ ] SQL scripts organized & commented
- [ ] Executive summary PDF
- [ ] Optional: 5-minute video walkthrough

---

## 🎯 Success Criteria

**Your project succeeds when:**
- ✅ Dashboard loads in under 3 seconds
- ✅ All KPIs are clearly defined and calculated correctly
- ✅ Visualizations are intuitive (no explanation needed)
- ✅ Insights are actionable (not just descriptive)
- ✅ Documentation is complete (someone else could recreate it)
- ✅ You can explain it confidently in an interview

---

## 🚨 Common Pitfalls to Avoid

1. **Over-complicating the dashboard**
   - Start with 5-6 core KPIs, not 20
   - Simple is better than fancy

2. **Ignoring the business context**
   - Call center managers care about efficiency + satisfaction
   - Executives care about trends + cost

3. **Forgetting data quality checks**
   - Always validate calculations
   - Check for outliers that skew averages

4. **Making Tableau too complicated**
   - Pre-calculate everything in SQL
   - Keep Tableau for visualization only

---

## 💡 Pro Tips from Project #3

**What worked well:**
- Breaking SQL into numbered files (01, 02, 03...)
- Pre-processing EVERYTHING in SQL before Tableau
- Creating one clean CSV export
- Using simple chart types

**What to avoid:**
- Complex Tableau calculations (do them in SQL!)
- Multi-select fields (flatten them upstream)
- Too many columns in the export

---

## 📚 Resources

**Call Center KPIs:**
- Average Handle Time (AHT)
- First Call Resolution (FCR)
- Service Level (% calls answered within X seconds)
- Abandonment Rate
- Customer Satisfaction Score (CSAT)
- Net Promoter Score (NPS)

**Tableau Best Practices:**
- Use KPI scorecards for big numbers
- Trend lines for time series
- Bar charts for comparisons
- Heatmaps for patterns

---

## 🎓 This is Your FINAL Project!

After this, you'll have:
- ✅ Google Business Intelligence Certificate
- ✅ 2 portfolio projects (AI ROI + Call Center Dashboard)
- ✅ Demonstrated SQL, Tableau, and business analysis skills
- ✅ Ready to apply for BI Analyst roles

**Let's finish strong! 💪**
