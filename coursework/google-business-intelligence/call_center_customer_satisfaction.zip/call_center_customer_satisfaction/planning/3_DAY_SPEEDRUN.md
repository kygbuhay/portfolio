# 3-DAY SPEEDRUN PLAN ⚡

> **Portfolio-ready in 72 hours. Let's go.**

---

## 📅 Day 1: Data Foundation (2 hours)
**Status:** [ ] Complete

### Morning Session (2 hours)
- [ ] Download 3 CSVs from Coursera
- [ ] Upload to BigQuery
- [ ] Run `01_union_all.sql` (creates unified view)
- [ ] Run `02_kpi_calculations.sql` (creates KPI tables)
- [ ] Export 3 CSVs for Tableau
- [ ] Update data_dictionary.md with actual values
- [ ] Git commit + push

**End-of-day checkpoint:**
✓ Do you have 3 CSV files in `/data/processed/`?  
✓ Can you query `kpi_market_summary` in BigQuery?  
✓ Is your repo pushed to GitHub?

**If yes to all three → Day 1 DONE. Take a break!**

---

## 📅 Day 2: Dashboard Build (3-4 hours)
**Status:** [ ] Complete

### Morning Session (2 hours)
**Part 1: Tableau Setup (30 min)**
- [ ] Connect kpi_daily.csv to Tableau
- [ ] Verify date fields are recognized as dates
- [ ] Create relationships if using multiple CSVs (or just use kpi_daily)

**Part 2: KPI Cards (45 min)**
Create 4 KPI scorecards at top of dashboard:
- [ ] Overall Repeat Call Rate (RCR %)
- [ ] Overall First Contact Resolution (FCR %)
- [ ] Total Calls Analyzed
- [ ] Date Range covered

Format: Large numbers, simple, clean (reference your AI ROI project style)

**Part 3: Market Comparison (45 min)**
- [ ] Bar chart: RCR by Market (sorted high to low)
- [ ] Add FCR on secondary axis or separate chart
- [ ] Add tooltips showing total calls per market

### Afternoon Session (1-2 hours)
**Part 4: Problem Type Analysis (45 min)**
- [ ] Horizontal bar chart: RCR by Problem Type
- [ ] Sort by RCR (worst offenders at top)
- [ ] Add call volume as size/color for context

**Part 5: Trend Over Time (45 min)**
- [ ] Line chart: RCR over time (use weekly data for smoother trends)
- [ ] Add filters: Market, Problem Type
- [ ] Optional: add reference line at 15% (industry target)

**Part 6: Simple Table (15 min)**
- [ ] Crosstab: Market × Problem Type × RCR
- [ ] Keep it simple - this satisfies Coursera rubric requirement

### Evening: Polish (30 min)
- [ ] Add dashboard title: "Google Fiber Repeat Call Analysis"
- [ ] Format colors (use greens for low RCR, reds for high)
- [ ] Add filter controls (date range, market selector)
- [ ] Test interactivity - do filters work?
- [ ] Save workbook

**End-of-day checkpoint:**
✓ Dashboard has 6 visualizations?  
✓ KPI cards show reasonable numbers (RCR 10-40%)?  
✓ Filters change the visuals when clicked?

**If yes → Day 2 DONE. Dashboard is functional!**

---

## 📅 Day 3: Insights & Documentation (3-4 hours)
**Status:** [ ] Complete

### Morning Session (2 hours)
**Part 1: Analyze Your Dashboard (60 min)**
Spend real time exploring. Answer these questions:
- Which market has highest RCR? By how much?
- Which problem type is worst? What % of total calls?
- Any time trends? (Improving? Getting worse? Seasonal?)
- What's working well? (Don't just focus on problems!)
- Any surprising patterns?

Take notes → these become your insights.

**Part 2: Write Insights (60 min)**
- [ ] Fill out `docs/insights_summary.md`
- [ ] Write 5 key findings (quantified with numbers!)
- [ ] Write 3 business recommendations (specific & actionable)
- [ ] Draft executive summary (2-3 sentences)

### Afternoon Session (1-2 hours)
**Part 3: Documentation (60 min)**
- [ ] Update README.md:
  - Fill in executive summary with your findings
  - Add Tableau Public link (after publishing)
  - Add 3 business recommendations
  - Update with actual KPI numbers
- [ ] Final polish on data_dictionary.md
- [ ] Add 2-3 dashboard screenshots to `/assets/screenshots/`

**Part 4: Publish & Share (30 min)**
- [ ] Publish dashboard to Tableau Public
- [ ] Update README with live link
- [ ] Git commit all docs
- [ ] Push to GitHub
- [ ] Test: Click your GitHub repo link - does everything look good?

**Part 5: Optional - Video Walkthrough (30 min)**
If you want extra portfolio points:
- [ ] Record 3-minute Loom video walking through dashboard
- [ ] Add video link to README

### Final Validation
**Run through this checklist:**
- [ ] GitHub repo is public and has clear README
- [ ] Tableau dashboard is published and accessible
- [ ] Dashboard tells a story (not just random charts)
- [ ] README includes quantified insights
- [ ] SQL scripts are documented and reproducible
- [ ] Data dictionary is complete
- [ ] You can explain the project in 2 minutes

**If all checked → PROJECT COMPLETE! 🎉**

---

## 🚀 Post-Completion (Optional Enhancements)

**If you have extra time or want to upgrade later:**

### SQL Enhancements
- [ ] Run `03_long_form_rollups.sql` for day-offset analysis
- [ ] Add insight: "Most repeats happen within 24-48 hours"
- [ ] Create additional KPI: Average days until repeat call

### Dashboard Enhancements
- [ ] Add "drill-down" detail sheets for each market
- [ ] Add annotations for notable events/spikes
- [ ] Create mobile-friendly version
- [ ] Add calculated field for month-over-month change

### Documentation Enhancements
- [ ] Write blog post about the project
- [ ] Create project case study (Problem → Analysis → Solution → Impact)
- [ ] Add to LinkedIn as featured project

---

## 🧠 ADHD-Friendly Reminders

**If you start to spiral:**
1. ✅ Check: Did I complete the baseline for this day? (If yes, STOP and take a break)
2. ⏰ Set 90-min timer and work ONLY on current task
3. 🎯 Remember: Done > Perfect. This is Coursera requirement + portfolio piece, not a PhD thesis.
4. 📝 Feeling stuck? Write down the EXACT blocker and message Claude.

**Energy management:**
- Day 1 afternoon? ✅ You're ahead of schedule!
- Day 2 evening? ✅ Right on track!
- Day 3 afternoon? ⏰ Push through - finish line is close!
- Past Day 3? 🆘 Reassess scope with Claude

**Remember:** You already proved you can do this with Project #3. This one is actually SIMPLER - it's just call center metrics, not complex analysis. Trust your process.

---

## 📊 Time Tracking

| Day | Planned | Actual | Notes |
|-----|---------|--------|-------|
| Day 1 | 2h | __ | |
| Day 2 | 4h | __ | |
| Day 3 | 4h | __ | |
| **Total** | **10h** | __ | Target: <12h |

---

**This is your LAST Coursera project. You got this! 💪**
