# Google Fiber Project - Day 1 Quick Start

## 🎯 Goal: Get project set up and understand the data

**Time estimate:** 2-3 hours

---

## ☐ Step 1: Download Data from Coursera (15 min)

1. Go to Coursera → Google Business Intelligence Certificate → Final Capstone
2. Download the Google Fiber dataset (likely a CSV or multiple CSVs)
3. Save to your Downloads folder
4. Note: What files did you get? How many rows?

---

## ☐ Step 2: Create GitHub Repo (10 min)

```bash
# In your terminal:
mkdir google-fiber-call-center-dashboard
cd google-fiber-call-center-dashboard
git init
```

Create this folder structure:
```
google-fiber-dashboard/
├── README.md (create empty file for now)
├── data/
│   ├── raw/
│   └── processed/
├── sql/
├── docs/
└── presentation/
```

---

## ☐ Step 3: First Look at the Data (30 min)

**Option A: In Excel/Google Sheets**
- Open the CSV
- How many rows?
- What are the columns?
- What does one row represent? (one call? one day?)

**Option B: In BigQuery (if you want to use it)**
- Create new dataset: `google_fiber`
- Upload CSV
- Run: `SELECT * FROM calls LIMIT 100;`

**Write down:**
- Total rows: _______
- Date range: _______ to _______
- Key columns: _______

---

## ☐ Step 4: Read Project Requirements (20 min)

From Coursera, find:
- What does the project ask you to deliver?
- What questions should the dashboard answer?
- Who is the intended audience?

**Write down the 3-5 most important business questions**

Example:
1. What are the busiest call times?
2. What call reasons have lowest satisfaction?
3. How many customers call multiple times?

---

## ☐ Step 5: Identify Key Metrics (30 min)

Based on the data columns, which KPIs can you calculate?

Check for these common call center metrics:
- [ ] Call volume (count of calls by day/week)
- [ ] Average handle time (if duration column exists)
- [ ] First call resolution (if there's a resolution flag)
- [ ] Repeat callers (if customer ID exists)
- [ ] Satisfaction scores (if CSAT column exists)
- [ ] Call reasons (if reason/type column exists)

**List the 5-6 KPIs you CAN calculate:**
1. _______
2. _______
3. _______
4. _______
5. _______

---

## ☐ Step 6: Create Data Dictionary (30 min)

Make a simple table documenting each column:

| Column Name | Data Type | Description | Example Values |
|-------------|-----------|-------------|----------------|
| call_id | String | Unique call identifier | "C12345" |
| call_date | Date | When call occurred | "2024-01-15" |
| ... | ... | ... | ... |

Save as: `docs/data_dictionary.md`

---

## ☐ Step 7: Come Back to Claude (5 min)

Once you've completed steps 1-6, come back and tell me:

1. **What data did you get?**
   - File name(s)
   - Number of rows
   - Date range

2. **What columns are in the data?**
   - Just list the column names

3. **What KPIs can you calculate?**
   - Which metrics are possible based on available columns

4. **What questions from Coursera do you need to answer?**
   - The 3-5 business questions from the requirements

Then I'll help you plan your SQL queries and dashboard structure!

---

## 🎉 When You Finish Day 1

You should have:
- ✅ Data downloaded and explored
- ✅ GitHub repo created with folder structure
- ✅ Understanding of what the project requires
- ✅ List of KPIs you can calculate
- ✅ Basic data dictionary started

**Total time:** 2-3 hours

**Next session:** We'll write SQL to calculate your KPIs and prep data for Tableau.

---

## 🆘 If You Get Stuck

**Can't find the dataset?**
- Check Coursera project instructions
- Look for "Resources" or "Dataset" link
- It might be in the project rubric

**Data looks weird?**
- That's normal! We'll clean it in SQL
- Just note what looks odd and we'll fix it

**Don't know what KPIs to calculate?**
- That's fine! Come back after Step 5 and we'll figure it out together
- Start with the simplest: call volume by day

**Feeling overwhelmed?**
- Just do Steps 1-3 (download, create repo, look at data)
- Come back and we'll tackle the rest together

---

**Remember:** This is your LAST Coursera project. You've already conquered Project #3 (which was harder!). You got this! 💪
