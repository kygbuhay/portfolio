# Key Insights & Recommendations

> **Fill this out on Day 3 after analyzing your dashboard**

---

## 📊 Executive Summary (2-3 sentences)

[Describe the overall situation with numbers]

Example:
"Analysis of 500K+ customer calls across three markets reveals a 23% repeat call rate, well above the 15% industry benchmark. Market 3 shows 2x higher repeat rates than other markets, driven primarily by Type_5 issues (Internet/WiFi troubleshooting)."

---

## 🔍 Key Findings

### Finding #1: [Highest-impact insight]
**Observation:** [What did you see in the data?]
- Market/Type: [specific details]
- Metric: [quantify it - "40% higher than average"]
- Time period: [when did this occur?]

**Why it matters:** [Business impact]

**Root cause hypothesis:** [Your educated guess based on data]

---

### Finding #2: [Second most important]
**Observation:** 

**Why it matters:**

**Root cause hypothesis:**

---

### Finding #3: [Pattern or trend]
**Observation:**

**Why it matters:**

**Root cause hypothesis:**

---

### Finding #4: [Positive insight - what's working?]
**Observation:** [Don't just focus on problems - highlight successes too!]

**Why it matters:**

---

### Finding #5: [Optional - temporal or seasonal pattern]
**Observation:**

**Why it matters:**

---

## 💡 Business Recommendations

### Priority 1: [Immediate action - highest ROI]
- **What:** [Specific action to take]
- **Why:** [Data-driven justification]
- **Expected impact:** [Quantified if possible, e.g., "Could reduce Market 3 RCR by 5-10%"]
- **Effort:** [Low/Medium/High]
- **Owner:** [Who should lead this - e.g., "Call Center Operations Manager"]

---

### Priority 2: [Medium-term improvement]
- **What:**
- **Why:**
- **Expected impact:**
- **Effort:**
- **Owner:**

---

### Priority 3: [Long-term strategic]
- **What:**
- **Why:**
- **Expected impact:**
- **Effort:**
- **Owner:**

---

## 📈 Success Metrics

**How to measure if recommendations work:**
- [ ] Reduce overall RCR from [current X%] to [target Y%] within 90 days
- [ ] Improve Market 3 FCR from [X%] to [Y%]
- [ ] Decrease [Problem Type] repeat rate by [Z%]
- [ ] Maintain or improve CSAT while reducing repeat calls

---

## 🎯 Call to Action

[1-2 sentences on immediate next steps]

Example:
"Immediate focus should be on Market 3's Type_5 resolution process. Recommend conducting root-cause analysis of sample calls and updating troubleshooting scripts within 2 weeks."

---

## 📝 Analysis Notes

**Limitations:**
- [Any data quality issues that affected analysis]
- [Time periods with incomplete data]
- [Assumptions made in calculations]

**Future Analysis Opportunities:**
- [What additional data would be helpful?]
- [What deeper dives could be valuable?]
- [What A/B tests could validate hypotheses?]

---

**Template Tips:**
1. Use specific numbers, not vague language ("28% RCR" not "high repeat rate")
2. Compare to benchmarks or other markets for context
3. Every finding needs a "so what?" - why does it matter?
4. Recommendations should be actionable (not just "improve processes")
5. Quantify expected impact when possible
